<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><?php echo e(__('Add new ') . $entity->heading); ?></div>
            <div class="card-body">
                <form class="frmMain" method="post" action="<?php echo e(route('save.entity.records', ['entityid' => $entity->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <?php $__currentLoopData = $entity->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $fieldAttributes = [];
                            foreach($attribute->attributeValues as $attributeValue) {
                                $fieldAttributes[$attributeValue->key] = $attributeValue->value;
                                if($attributeValue->key == 'excel_file') {
                                    $filepath = DOC_ROOT . $attributeValue->value;
                                    if(file_exists($filepath)) {
                                        $excel = \Importer::make('Excel');
                                        $excel->load($filepath);
                                        $collection = $excel->getCollection()->toArray();
                                        $fieldAttributes['options'] = $collection;
                                    }
                                }
                            }
                        ?>
                        <div class="col-md-4">
                            <?php echo $helperModel->renderFormField([
                                    'field' => FIELD_TYPES_INDEX[$attribute->attribute_type],
                                    'attributes' => $fieldAttributes,
                                ]); ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row">
                        <div class="col-md-12 text-right">
                            <button class="btn btn-success btn-sm"><i class="fa fas fa-save"></i> Save <?php echo e($entity->heading); ?></button>
                            <a href="<?php echo e(route('list.entity.records', ['entityid' => $entity->id])); ?>" class="btn btn-danger btn-sm"><i class="fa fas fa-times"></i> Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscode'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/entity/entity-rec-add.blade.php ENDPATH**/ ?>