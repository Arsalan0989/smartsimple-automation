<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Update Entity')); ?></div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="basic-tab" data-toggle="tab" href="#basic" role="tab"
                                aria-controls="basic" aria-selected="true">Basic Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="attribute-tab" data-toggle="tab" href="#attribute" role="tab"
                                aria-controls="attribute" aria-selected="false">Entity Properties</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="basic" role="tabpanel" aria-labelledby="basic-tab">
                            <form class="frmMain my-2" action="<?php echo e(route('entity.update', ['entity' => $entity->id])); ?>"
                                method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <div class="row">
                                    <?php echo $__env->make('entity._frm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <div class="col-md-12 text-right">
                                        <button class="btn btn-success"><i class="fa fas fa-save"></i> Update</button>
                                        <a class="btn btn-danger" href="<?php echo e(route('entity.index')); ?>"><i
                                                class="fa fas fa-times"></i> Cancel</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="attribute" role="tabpanel" aria-labelledby="attribute-tab">
                            <?php if(!empty($entity->id)): ?>
                                <?php echo $__env->make('entity._attribute-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jscode'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/entity/edit.blade.php ENDPATH**/ ?>