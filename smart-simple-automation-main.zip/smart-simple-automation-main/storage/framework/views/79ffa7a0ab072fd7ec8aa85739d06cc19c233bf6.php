
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>


    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('app-ui/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-ui/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('app-ui/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('app-ui/js/sb-admin-2.min.js')); ?>"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
        integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <?php if(Session::has('success')): ?>
        <script>
            toastr.success("<?php echo Session::get('success'); ?>");
        </script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            toastr.error("<?php echo Session::get('error'); ?>");
        </script>
    <?php endif; ?>
    <?php if(Session::has('warning')): ?>
        <script>
            toastr.warning("<?php echo Session::get('warning'); ?>");
        </script>
    <?php endif; ?>
    <?php echo $__env->yieldContent('jscode'); ?>
    <?php echo $__env->make('layouts.common-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/login-reg/_incpost.blade.php ENDPATH**/ ?>