<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e($entity->menu_title . ' Records'); ?></div>
                <div class="card-body">
                    <?php if($records->count() > 0): ?>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <?php $__currentLoopData = $entity->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attHead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($attHead->slug); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php $__currentLoopData = $entity->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attHead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($record->entityDataValues->where('attribute_value_id', $helperModel->entityAttributeSubmittedDataId($attHead))->pluck('attribute_entity_value')); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td>Actions</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div>
                            <?php echo $records->render(); ?>

                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No entity added yet. <a href="<?php echo e(route('add.entity.records', ['entityid' => $entity->id])); ?>"><i class="fa fas fa-plus"></i> Add new <?php echo e($entity->heading); ?>.</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/entity/entityrecs.blade.php ENDPATH**/ ?>