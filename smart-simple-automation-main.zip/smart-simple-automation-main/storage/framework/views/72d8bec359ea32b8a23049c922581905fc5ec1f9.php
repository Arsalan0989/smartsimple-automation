<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Clients Listing')); ?></div>
                <div class="card-body">
                    <?php if($clients->count() > 0): ?>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th>Name</th>
                            <th>Organization</th>
                            <th>Location</th>
                            <th>Actions</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($client->name); ?></td>
                                    <td><?php echo e($client->organization); ?></td>
                                    <td><?php echo e($client->city . ', ' . $client->country); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                              Actions
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="<?php echo e(route('client.edit', ['client' => $client->id])); ?>" class="text-info"><i class="fa fas fa-edit"></i> Modify</a>
                                                <form action="<?php echo e(route('client.destroy', ['client' => $client->id])); ?>" method="post" class="form-inline">
                                                    <button class="text-danger"><i class="fa fas fa-trash"></i> Delete</button>
                                                    <input type="hidden" name="_method" value="delete" />
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                </form>
                                            </div>
                                          </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div>
                        <?php echo $clients->links('pagination::bootstrap-4'); ?>

                    </div>
                    <?php else: ?>
                        <div class="alert alert-info">No client added yet. <a href="<?php echo e(route('client.create')); ?>"><i class="fa fas fa-plus"></i> Add new client.</a></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/client/index.blade.php ENDPATH**/ ?>