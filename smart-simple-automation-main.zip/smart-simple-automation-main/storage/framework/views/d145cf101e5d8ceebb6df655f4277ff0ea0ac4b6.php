<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <?php echo e(__('Forms Listing')); ?> 
                    <span style="float: right">
                        <a href="<?php echo e(route('form.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add New Form</a>
                    </span>
                </div>
                <div class="card-body">
                    <?php if($forms->count() > 0): ?>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th>Name Form</th>
                            <th>Shortcode</th>
                            <th>Created</th>
                            <th>Status</th>
                            <th>Options</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($form->fmb_name); ?></td>
                                    <td>
                                        <button class="btn btn-warning">Get shortcode</button>
                                    </td>
                                    <td><?php echo e($form->created_date); ?></td>
                                    <td>
                                        <?php if($form->flag_status==1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?> 
                                            <span class="badge badge-danger">In-Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                        <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Move to Trash</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="alert alert-info">No client added yet. <a href="<?php echo e(route('client.create')); ?>"><i class="fa fas fa-plus"></i> Add new client.</a></div>
                    <?php endif; ?>

                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscode'); ?>
    <script>
        jQuery(document).ready(function ($) {
            $('#zgfm-listform-filter-panel').on('shown.bs.collapse', function (e) {
                /* Get clicked element that initiated the collapse...*/
                var $clickedBtn = $(e.target).data('bs.collapse').$trigger;
                /*add active to button*/
                $clickedBtn.addClass('sfdc-active');
            });
            $('#zgfm-listform-filter-panel').on('hidden.bs.collapse', function (e) {
                /* Get clicked element that initiated the collapse...*/
                var $clickedBtn = $(e.target).data('bs.collapse').$trigger;
                /*remove active to button*/
                $clickedBtn.removeClass('sfdc-active');
            });
            
            /*list form refresh params*/
            /*event filter */
            $(document).on( "keyup change","#zgfm-listform-pref-perpage,#zgfm-listform-pref-search,#zgfm-listform-pref-orderby" , function(e) {
                zgfm_back_general.formslist_search_refresh();
            });
            
            /*trigger filter */
            zgfm_back_general.formslist_search_refresh();
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/form/index.blade.php ENDPATH**/ ?>