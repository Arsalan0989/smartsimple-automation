<div class="zgfm-blocked-message-box">
	<h2>
		<i class="fa fa-lock"></i>
		<?php echo $message . ' ' . __( 'is a PRO Feature'); ?>
	</h2>
	<div class="zgfm-blocked-message-box-msg">
		<?php echo __( 'We\'re sorry, %s is not available on free version.<br><br>Please upgrade to Pro version to unlocks all these features, and puts you on the upgrade path for additional features that we’re excited to share in the near future.'.$message); ?>
	</div>
	<div class="zgfm-blocked-message-box-btn">
		<a 
			href="https://1.envato.market/Ymxgq"
			 target="_blank"
			class="sfdc-btn sfdc-btn-success sfdc-btn-lg"> <span><?php echo __( 'UPGRADE TO PRO VERSION'); ?></span></a>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/settings/blocked_getmessage.blade.php ENDPATH**/ ?>