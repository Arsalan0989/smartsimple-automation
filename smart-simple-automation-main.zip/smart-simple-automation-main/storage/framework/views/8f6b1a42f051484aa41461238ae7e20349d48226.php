<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Update Client')); ?></div>
                <div class="card-body">
                    <form class="frmMain" action="<?php echo e(route('client.update', ['client' => $client->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div class="row">
                            <?php echo $__env->make('client._frm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="col-md-12 text-right">
                                <button class="btn btn-success"><i class="fa fas fa-save"></i> Update</button>
                                <a class="btn btn-danger" href="<?php echo e(route('client.index')); ?>"><i class="fa fas fa-times"></i> Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/client/edit.blade.php ENDPATH**/ ?>