<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Entities Listing')); ?></div>
                <div class="card-body">
                    <?php if($entities->count() > 0): ?>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th>Parent</th>
                            <th>Has Childs</th>
                            <th>Heading</th>
                            <th>Icon</th>
                            <th>Menu</th>
                            <th>Menu Show</th>
                            <th>Active</th>
                            <th>Actions</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $entities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(empty($entity->parent_id) ? 'None' : 'Yes'); ?></td>
                                    <td><?php echo e(YESNO[$entity->has_childs]); ?></td>
                                    <td><?php echo e($entity->heading); ?></td>
                                    <td><img src="<?php echo e(asset($entity->icon)); ?>" class="img-fluid iconImg"/></td>
                                    <td><?php echo e($entity->menu_title); ?></td>
                                    <td><?php echo e($entity->show_in_menu); ?></td>
                                    <td><?php echo e($entity->published); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                              Actions
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="<?php echo e(route('entity.edit', ['entity' => $entity->id])); ?>" class="text-info"><i class="fa fas fa-edit"></i> Modify</a>
                                                <form action="<?php echo e(route('entity.destroy', ['entity' => $entity->id])); ?>" method="post" class="form-inline">
                                                    <button class="text-danger"><i class="fa fas fa-trash"></i> Delete</button>
                                                    <input type="hidden" name="_method" value="delete" />
                                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                </form>
                                            </div>
                                          </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div>
                        <?php echo $entities->render(); ?>

                    </div>
                    <?php else: ?>
                    <div class="alert alert-info">No entity added yet. <a href="<?php echo e(route('entity.create')); ?>"><i class="fa fas fa-plus"></i> Add new entity.</a></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smart-simple-automation-main\resources\views/entity/index.blade.php ENDPATH**/ ?>