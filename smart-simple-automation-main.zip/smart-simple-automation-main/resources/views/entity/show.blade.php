{{--
    @extends('layouts.app')

    @section('content')
        entity.show template
    @endsection
--}}
