{{--
    @extends('layouts.app')

    @section('content')
        fieldset.index template
    @endsection
--}}
