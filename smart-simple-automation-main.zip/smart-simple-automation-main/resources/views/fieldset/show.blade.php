{{--
    @extends('layouts.app')

    @section('content')
        fieldset.show template
    @endsection
--}}
