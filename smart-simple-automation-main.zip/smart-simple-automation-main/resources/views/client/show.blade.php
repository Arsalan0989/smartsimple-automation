{{--
    @extends('layouts.app')

    @section('content')
        client.show template
    @endsection
--}}
